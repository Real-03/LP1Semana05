﻿namespace Bogus.Tests.Models;

public class Order
{
   public int OrderId { get; set; }
   public string Item { get; set; }
   public int Quantity { get; set; }
}