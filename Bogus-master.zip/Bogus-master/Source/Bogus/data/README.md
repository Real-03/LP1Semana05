:stop_sign: :stop_sign: :stop_sign: :stop_sign: :stop_sign: :stop_sign:
```
  XXXXX  XXXXXXX   XXX   XXXXXX
 X     X X  X  X  X   X   X    X
 X          X    X     X  X    X
 X          X    X     X  X    X
  XXXXX     X    X     X  XXXXX
       X    X    X     X  X
       X    X    X     X  X
 X     X    X     X   X   X
  XXXXX    XXX     XXX   XXXX
```
:stop_sign: :stop_sign: :stop_sign: :stop_sign: :stop_sign: :stop_sign: 

## The files in this folder are auto-generated

Any modifications to files in this folder will be clobbered.

If you wish to change the `data` in this folder, use the `data_extend` folder instead.

See wiki for more info:
https://github.com/bchavez/Bogus/wiki/Creating-Locales