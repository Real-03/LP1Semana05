﻿namespace Bogus.Premium;

public static class License
{
   public static string LicenseTo { get; set; }
   public static string LicenseKey { get; set; }
}