[1]:https://github.com/bchavez/Bogus#the-great-c-example

## Getting Started with Bogus

#### Requirements
* **.NET Core 3.1** or later

#### Description

The `GettingStarted` example is the full working example of [**"The Great C# Example"**][1] on the homepage of this repository.

To run the example, perform the following commands *inside* this `GettingStarted` folder:

  * `dotnet restore`
  * `dotnet build`
  * `dotnet run`
  
After the `dotnet` commands are successfully executed above, you should see some fake JSON data printed to the console!